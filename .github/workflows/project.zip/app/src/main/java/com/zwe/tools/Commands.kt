package com.zwe.tools

import android.content.Context

data class Cmd(val l: Int, val n: String, val f: String)

const val CM = "1:a:x,1:sp:i,1:spoff:,1:az:,1:alic:i,1:admins:,1:medias:,1:arep:,1:ans:ix,1:setpass:x,1:gm:,1:flip:i,1:fixcar:i,1:getinfo:i,1:hp:iv,2:spawn:i,2:freeze:i,2:tp:,2:stats:i,2:slap:i,2:mark:,2:gotomark:,2:weap:i,2:pay:ia,2:skills:i,2:kick:ir,2:mute:itr,2:unmute:i,2:offmute:itr,2:jail:itr,2:unjail:i,2:offjail:itr,2:offunjail:n,2:rmute:itr,2:runmute:i,2:gotocar:i,2:getcar:i,2:goto:i,2:checkpunish:nt,2:heal:i,2:deadlist:i,3:ban:itr,3:warn:nr,3:offwarn:nr,3:unwarn:n,3:offunwarn:n,3:skick:i,3:veh_find:,3:gethere:i,3:hpall:v,3:weapall:,3:arm:iv,3:uncuff:i,3:find:,3:acceptgnews:,3:as:x,3:tempfrac:,4:sban:itr,4:unban:i,4:house:v,4:biz:v,4:okay:i,4:no:ir,4:setskin:iv,4:offban:itr,4:ears:,4:rgun:i,4:setfuel:iv,4:getname:v,4:spcar:v,4:history:n,4:lip:x,4:spcars:,4:leaders:"

val CMDS: List<Cmd> = CM.split(",").map { val p = it.split(":"); Cmd(p[0].toInt(), p[1], p[2]) }

fun loadTemplates(c: Context): List<String> {
    val s = c.getSharedPreferences("zwe", Context.MODE_PRIVATE).getString("tpl", null)
    if (s.isNullOrBlank()) return listOf(
        "Assalomu alaykum, kuting!",
        "Assalomu alaykum, Bunday xizmatlar ko'rsatmaymiz.",
        "Assalomu alaykum, Dalilingiz bo'lsa shikoyat yuboring."
    )
    return s.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
}
