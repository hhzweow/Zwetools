package com.zwe.tools

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("zwe", Context.MODE_PRIVATE)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(40, 60, 40, 60)

        fun tv(s: String, size: Float = 16f): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = size
            t.setTextColor(Color.WHITE)
            t.setPadding(0, 24, 0, 8)
            return t
        }
        fun bt(s: String, f: () -> Unit): Button {
            val b = Button(this)
            b.text = s
            b.isAllCaps = false
            b.setOnClickListener { f() }
            return b
        }

        col.addView(tv("Zwe TOOLS 1.0", 28f))
        col.addView(tv("1) Klaviaturani yoqing, 2) uni tanlang."))
        col.addView(bt("1. Klaviaturani yoqish") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(bt("2. Klaviaturani tanlash") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        col.addView(tv("Admin darajasi"))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("1", "2", "3", "4"))
        sp.setSelection(p.getInt("level", 1) - 1)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                p.edit().putInt("level", pos + 1).apply()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        col.addView(sp)

        col.addView(tv("Tayyor javoblar (har qator bitta javob)"))
        val et = EditText(this)
        et.setText(loadTemplates(this).joinToString("\n"))
        et.setTextColor(Color.WHITE)
        et.minLines = 4
        et.gravity = Gravity.TOP
        col.addView(et)
        col.addView(bt("Saqlash") {
            p.edit().putString("tpl", et.text.toString()).apply()
            Toast.makeText(this, "Saqlandi", Toast.LENGTH_SHORT).show()
        })

        col.addView(tv("Sinov maydoni"))
        val test = EditText(this)
        test.hint = "Bu yerga yozib klaviaturani sinang"
        test.setTextColor(Color.WHITE)
        col.addView(test)

        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF0B0D1F.toInt())
        sv.addView(col)
        setContentView(sv)
    }
}
