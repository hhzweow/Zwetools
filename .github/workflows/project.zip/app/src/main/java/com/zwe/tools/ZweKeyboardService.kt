package com.zwe.tools

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ZweKeyboardService : InputMethodService() {
    private lateinit var root: LinearLayout
    private var mode = "keys"
    private var ru = false
    private var shift = false
    private var sym = false
    private var idBuf = ""
    private var pending: Cmd? = null

    private val en = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val rus = listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
    private val symRows = listOf("1234567890", "@#$%&-+()/", "*\"':;!?,._")

    override fun onCreateInputView(): View {
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0B0D1F.toInt())
        root.setPadding(dp(4), dp(4), dp(4), dp(4))
        draw()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        mode = "keys"
        pending = null
        if (::root.isInitialized) draw()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun level(): Int = getSharedPreferences("zwe", Context.MODE_PRIVATE).getInt("level", 1)

    private fun put(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun btn(label: String, bg: Long = 0xFF3A3F6B, w: Float = 1f, h: Int = 46, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 16f
        b.setPadding(0, 0, 0, 0)
        val g = GradientDrawable()
        g.cornerRadius = dp(10).toFloat()
        g.setColor(bg.toInt())
        b.background = g
        val lp = if (w < 0f) LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(h))
        else LinearLayout.LayoutParams(0, dp(h), w)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        for (x in v) r.addView(x)
        return r
    }

    private fun draw() {
        root.removeAllViews()
        when (mode) {
            "admin" -> admin()
            "id" -> idPad()
            "tpl" -> tplList()
            else -> keys()
        }
    }

    private fun keys() {
        root.addView(row(
            btn("Admin", 0xFF5B4B9A) { mode = "admin"; draw() },
            btn("Replies", 0xFF3F5B7A) { pending = null; mode = "tpl"; draw() },
            btn(if (ru) "EN" else "RU", 0xFF5B4B9A) { ru = !ru; draw() },
            btn(if (sym) "ABC" else "123", 0xFF355567) { sym = !sym; draw() }
        ))
        val rows = if (sym) symRows else listOf("1234567890") + (if (ru) rus else en)
        for (r in rows) {
            val keyViews = r.map { ch ->
                val s = if (shift && !sym) ch.toString().uppercase() else ch.toString()
                btn(s, 0xFF394067) {
                    put(s)
                    if (shift) { shift = false; draw() }
                }
            }
            root.addView(row(*keyViews.toTypedArray()))
        }
        root.addView(row(
            btn("⇧", if (shift) 0xFF7C3AED else 0xFF4A4F7A, 1.3f) { shift = !shift; draw() },
            btn(if (ru) "Русский" else "English", 0xFF343C58, 4f) { put(" ") },
            btn("⌫", 0xFF4A4F7A, 1.3f) { currentInputConnection?.deleteSurroundingText(1, 0) },
            btn("⏎", 0xFF2F7390, 1.3f) { enter() }
        ))
    }

    private fun enter() {
        if (!sendDefaultEditorAction(true)) {
            val ic = currentInputConnection ?: return
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    private fun insertCmd(c: Cmd, id: String) {
        val rest = c.f.replace("i", "")
        put("/" + c.n + (if (id.isNotEmpty()) " $id" else "") + (if (rest.isNotEmpty()) " " else ""))
    }

    private fun admin() {
        root.addView(btn("← ABC", 0xFF6E7076, -1f, 40) { mode = "keys"; draw() })
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        for (chunk in CMDS.filter { it.l <= level() }.chunked(3)) {
            val bs = chunk.map { c ->
                btn("/" + c.n, 0xFF454D7A) {
                    pending = c
                    idBuf = ""
                    if (c.f.contains('i')) {
                        mode = "id"
                    } else {
                        insertCmd(c, "")
                        mode = "keys"
                    }
                    draw()
                }
            }
            box.addView(row(*bs.toTypedArray()))
        }
        val sv = ScrollView(this)
        sv.addView(box)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220))
        root.addView(sv)
    }

    private fun idPad() {
        val c = pending
        if (c == null) { mode = "keys"; draw(); return }
        val t = TextView(this)
        t.text = "/" + c.n + "   ID: " + idBuf
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(8), 0, dp(8))
        root.addView(t)
        for (r in listOf("123", "456", "789")) {
            val ds = r.map { d -> btn(d.toString(), 0xFF3D4670) { if (idBuf.length < 7) idBuf += d; draw() } }
            root.addView(row(*ds.toTypedArray()))
        }
        root.addView(row(
            btn("C", 0xFFA4623A) { idBuf = ""; draw() },
            btn("0", 0xFF3D4670) { if (idBuf.length < 7) idBuf += "0"; draw() },
            btn("⌫", 0xFFA4623A) { idBuf = idBuf.dropLast(1); draw() }
        ))
        root.addView(row(
            btn("← Orqaga", 0xFF6E7076) { mode = "admin"; draw() },
            btn("Davom →", 0xFF2F7390) {
                if (idBuf.isNotEmpty()) {
                    if (c.n == "ans") {
                        mode = "tpl"
                    } else {
                        insertCmd(c, idBuf)
                        mode = "keys"
                    }
                    draw()
                }
            }
        ))
    }

    private fun tplList() {
        root.addView(btn("← ABC", 0xFF6E7076, -1f, 40) {
            mode = if (pending != null) "id" else "keys"
            draw()
        })
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        for (tx in loadTemplates(this)) {
            box.addView(btn(tx, 0xFF454D7A, -1f, 52) {
                val p = pending
                if (p != null && p.n == "ans") put("/ans $idBuf $tx") else put(tx)
                pending = null
                mode = "keys"
                draw()
            })
        }
        val sv = ScrollView(this)
        sv.addView(box)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220))
        root.addView(sv)
    }
}
